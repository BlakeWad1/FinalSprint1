function showHideB() {
  var x = document.getElementById("more-blake").firstElementChild;
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function showHideT() {
  var x = document.getElementById("more-tyler").firstElementChild;
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function showHideS() {
  var x = document.getElementById("more-scott").firstElementChild;
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
